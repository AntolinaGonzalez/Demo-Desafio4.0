from django.apps import AppConfig


class BugConfig(AppConfig):
    name = 'bug'
