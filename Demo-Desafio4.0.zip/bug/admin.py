from django.contrib import admin
from .models import UploadImages, UploadTarget

# Register your models here.


admin.site.register(UploadImages)
admin.site.register(UploadTarget)



